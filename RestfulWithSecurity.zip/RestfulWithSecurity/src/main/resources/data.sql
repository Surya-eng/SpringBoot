Insert into USERS (USERNAME,PASSWORD,active) values ('surya','surya12','1');
Insert into USERS (USERNAME,PASSWORD,active) values ('naga','naga12','1');
Insert into AUTHORITTIES (USERNAME,AUTHORITY) values ('surya','ROLE_USER');
Insert into AUTHORITTIES (USERNAME,AUTHORITY) values ('naga','ADMIN');
commit;

