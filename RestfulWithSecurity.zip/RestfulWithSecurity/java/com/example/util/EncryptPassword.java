package com.example.util;

public class EncryptPassword {

	/*public static void main(String[] args) {
     System.out.println(new BCryptPasswordEncoder().encode("surya12"));
	}*/

}
