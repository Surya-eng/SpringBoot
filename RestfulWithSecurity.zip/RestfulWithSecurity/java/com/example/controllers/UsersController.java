package com.example.controllers;

import java.net.URI;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.example.entities.User;
import com.example.exception.UserNotFoundException;
import com.example.services.UsersService;

import lombok.extern.log4j.Log4j2;

@RestController
@RequestMapping(
		value = "/rest" 
		//consumes = MediaType.APPLICATION_JSON_VALUE,
		//produces = MediaType.APPLICATION_JSON_VALUE,
		//method = {RequestMethod.GET,RequestMethod.POST,RequestMethod.DELETE,RequestMethod.PUT}
		)
public class UsersController {
	
	@Autowired
	private UsersService usersService;
	Logger logger = LoggerFactory.getLogger(UsersController.class);
	 
    @RequestMapping("/")
    public String index() {
        logger.trace("A TRACE Message");
        logger.debug("A DEBUG Message");
        logger.info("An INFO Message");
        logger.warn("A WARN Message");
        logger.error("An ERROR Message");
        return "Howdy! Check out the Logs to see the output...";
    }
    

	@GetMapping("/user")
	public ResponseEntity<List<User>> getAllUsers() {
		logger.info("getAllUsers");
		List<User> users = usersService.getAllUsers();
		if (users.isEmpty()) {
			return new ResponseEntity<List<User>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<User>>(users, HttpStatus.OK);
	}

	@GetMapping("/user/{id}")
	public ResponseEntity<User> getUserById(@PathVariable(required = true) long id,UriComponentsBuilder ucb) {
		if(!usersService.isUserExist(id)) {
			logger.error("User with id {} not found.", id);
			throw new UserNotFoundException("User with id " + id + " not found.",HttpStatus.NOT_FOUND.value());
		}
		HttpHeaders headers = new HttpHeaders();
		headers.set("TEST", "TEST123");
		URI locationUri =
				  ucb.path("/spittles/").path(String.valueOf(id)).build().toUri();
				  headers.setLocation(locationUri);
		return new ResponseEntity<User>(usersService.getUserById(id),headers,HttpStatus.FOUND);
	}

	@PostMapping("/admin/add")
	@ResponseStatus(HttpStatus.CREATED)
	public void addUserByAdmin(@Valid @RequestBody User user,HttpServletRequest request,HttpServletResponse response) {
		logger.info("Creating User : {}", user);
		if (usersService.isUserExist(user.getId())) {
			logger.error("Unable to create. A User with ID {} already exist", user.getId());
			throw new UserNotFoundException("Unable to create. A User with this ID " +	user.getId() + " is already exist.",HttpStatus.CONFLICT.value());
		}
		long id=usersService.add(user);
		response.setHeader("userID",String.valueOf(id));
		response.setHeader("Location", request.getRequestURL().append(user.getId()).toString());
	}

	@PutMapping("/admin/edit")
	@ResponseStatus(HttpStatus.ACCEPTED)
	public void updateUserByAdmin(@Valid @RequestBody User user) {
		logger.info("Updating User with id {}", user.getId());
		if (!usersService.isUserExist(user.getId())) {
			logger.error("Unable to update. User with id {} not found.", user.getId());
			throw new UserNotFoundException("Unable to upate. User with id " + user.getId() + " not found.",HttpStatus.NOT_FOUND.value());
		}
		usersService.add(user);
	}

	@DeleteMapping("admin/delete/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void deleteUserByAdmin(@PathVariable(required = true) long id) {
		logger.info("Fetching & Deleting User with id {}", id);
		if (!usersService.isUserExist(id)){
			logger.error("Unable to delete. User with id {} not found.", id);
			throw new UserNotFoundException("Unable to delete. User with id " + id + " not found.",HttpStatus.NOT_FOUND.value());
		}
		usersService.delete(id);
	}

	@GetMapping("/403")
	public String error() {
		return "InSufficient Privileges & Please Contact Administrator";
	}
}
