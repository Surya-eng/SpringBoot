package com.example.confiig;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;

@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter{
	@Autowired
	private DataSource dataSource;
	private static final String GET_USERS="select username,password,'true' from users where username=?";
	private static final String GET_USERS_ROLES="select username,authority from AUTHORITTIES where username=?";
	/*@Override
	protected void configure(AuthenticationManagerBuilder authMgr) throws Exception {
		authMgr.inMemoryAuthentication()
		.withUser("surya").password("surya12").roles("user")
		.and()
		.withUser("naga").password("naga12").roles("admin"); 
	}*/

	@Override
	protected void configure(AuthenticationManagerBuilder authMgr) throws Exception {
		authMgr.jdbcAuthentication()
		.dataSource(dataSource)
		.usersByUsernameQuery(GET_USERS)
		.authoritiesByUsernameQuery(GET_USERS_ROLES)
		.passwordEncoder(NoOpPasswordEncoder.getInstance());
		//.passwordEncoder(new BCryptPasswordEncoder());
	}
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.csrf().disable();//to allow other http methods then GET
		
		//spring will prefix 'ROLE_'
		http.authorizeRequests() 
		.antMatchers("/*/admin/**").hasRole("ADMIN")
		.antMatchers("/*/user/**").hasAnyRole("USER","ADMIN")
		.antMatchers("/").permitAll()
		//.and().formLogin()
		.and().httpBasic()
		.and().exceptionHandling().accessDeniedPage("/403");          
	} 
}
