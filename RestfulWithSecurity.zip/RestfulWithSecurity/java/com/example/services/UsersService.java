package com.example.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entities.User;
import com.example.repository.UserRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UsersService {
	@Autowired
	private UserRepository userRepository;


	public Long add(User user) {
		return userRepository.save(user).getId();
	}
	public void delete(long id) {
		userRepository.deleteById(id);
	}
	public List<User> getAllUsers() {
		return (List<User>) userRepository.findAll();
	}
	public User getUserById(long id) {
		return userRepository.findAll().get(0);
	}
	public boolean isUserExist(Long id) {
		return userRepository.existsById(id);
	}
}
