package com.example.exception;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class ErrorResponse {
	//General error message about nature of error
	private String message;
	
	//Specific errors in API request processing
	@JsonInclude(Include.NON_NULL)
	private List<String> details;
	
	public ErrorResponse(String message) {
		super();
		this.message = message;
	}
	public ErrorResponse(String message, List<String> details) {
        super();
        this.message = message;
        this.details = details;
    }

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<String> getDetails() {
		return details;
	}

	public void setDetails(List<String> details) {
		this.details = details;
	}
}
